plugins { id("com.android.application") }
android {
    namespace = "no.plotteriet.mintimeplan"
    compileSdk = 35
    defaultConfig { applicationId = "no.plotteriet.mintimeplan"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "1.0" }
}
